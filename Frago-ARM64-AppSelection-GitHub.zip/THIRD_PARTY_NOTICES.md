# Third-party notices

## HevSocks5Tunnel

- Project: https://github.com/heiher/hev-socks5-tunnel
- Version: 2.20.0 (pinned by the GitHub Actions workflow)
- License: MIT
- The ARM64 native library is built from the upstream source during GitHub Actions. The upstream `LICENSE` is copied into the build workspace as `THIRD_PARTY_HEV_LICENSE.txt`.

## Source project

The Android application is derived from the uploaded SocksVPN-Lite/SocksDroid source, which contains GPL-3.0-covered code. The original `LICENSE` file is retained. Distribute corresponding source code and preserve applicable notices when redistributing builds.
