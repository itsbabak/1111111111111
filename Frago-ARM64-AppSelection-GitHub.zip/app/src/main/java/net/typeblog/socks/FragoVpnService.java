package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import hev.htproxy.TProxyService;
import net.typeblog.socks.core.FragoConfig;
import net.typeblog.socks.core.FragoSocksServer;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.security.SecureRandom;

public final class FragoVpnService extends VpnService {
    public static final String ACTION_START = "net.typeblog.frago.START";
    public static final String ACTION_STOP = "net.typeblog.frago.STOP";
    public static final String ACTION_STATUS = "net.typeblog.frago.STATUS";
    public static final String EXTRA_CONFIG = "frago.json";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_ALLOWED_APPS = "allowed_apps";
    private static final String TAG = "FragoVPN";
    private static final String CHANNEL = "frago-vpn";

    private ParcelFileDescriptor tun;
    private FragoSocksServer socksServer;
    private volatile boolean starting;
    private volatile boolean running;
    private String socksUsername;
    private String socksPassword;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) {
            stopTunnel();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction()) || starting || running) return START_STICKY;

        starting = true;
        startForeground(41, buildNotification("در حال راه‌اندازی موتور Frago"));
        final String json = intent.getStringExtra(EXTRA_CONFIG);
        final ArrayList<String> allowedApps = intent.getStringArrayListExtra(EXTRA_ALLOWED_APPS);
        new Thread(() -> startTunnel(json, allowedApps), "Frago-VPN-Start").start();
        return START_STICKY;
    }

    private void startTunnel(String json, ArrayList<String> allowedApps) {
        try {
            FragoConfig config = FragoConfig.parse(json);
            Builder builder = new Builder()
                    .setSession("Frago")
                    .setMtu(1500)
                    .addAddress("26.26.26.1", 24)
                    .addAddress("fd26:26:26::1", 126)
                    .addDnsServer("26.26.26.2")
                    .addRoute("0.0.0.0", 0)
                    .addRoute("::", 0);

            // An empty selection means the traditional all-apps VPN mode.
            // With a non-empty selection Android routes only those packages into this VPN.
            if (allowedApps != null && !allowedApps.isEmpty()) {
                int added = 0;
                for (String packageName : allowedApps) {
                    if (packageName == null || packageName.trim().isEmpty()
                            || packageName.equals(getPackageName())) continue;
                    try {
                        getPackageManager().getApplicationInfo(packageName, 0);
                        builder.addAllowedApplication(packageName);
                        added++;
                    } catch (android.content.pm.PackageManager.NameNotFoundException missing) {
                        Log.w(TAG, "Selected app is no longer installed: " + packageName);
                    }
                }
                if (added == 0) {
                    throw new IllegalStateException("هیچ‌کدام از برنامه‌های انتخاب‌شده نصب نیستند.");
                }
                Log.i(TAG, "Per-app VPN enabled for " + added + " applications.");
            } else {
                // Keep Frago's own SOCKS and DoH sockets outside its VPN to avoid a loop.
                builder.addDisallowedApplication(getPackageName());
                Log.i(TAG, "All-app VPN mode enabled (Frago excluded).");
            }

            tun = builder.establish();
            if (tun == null) throw new IllegalStateException("Android VPN interface could not be established.");

            byte[] sessionSecret = new byte[24];
            new SecureRandom().nextBytes(sessionSecret);
            String secret = toHex(sessionSecret);
            socksUsername = secret.substring(0, 24);
            socksPassword = secret.substring(24);
            socksServer = new FragoSocksServer(this, config, socksUsername, socksPassword);
            socksServer.start();

            File nativeConfig = new File(getFilesDir(), "frago-hev.yml");
            try (FileOutputStream out = new FileOutputStream(nativeConfig, false)) {
                out.write(config.toHevYaml(new File(getFilesDir(), "hev.log").getAbsolutePath(), socksUsername, socksPassword)
                        .getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

            if (!TProxyService.TProxyStartService(nativeConfig.getAbsolutePath(), tun.getFd()))
                throw new IllegalStateException("Hev tun2socks engine refused to start.");

            long deadline = java.lang.System.currentTimeMillis() + 5000L;
            while (java.lang.System.currentTimeMillis() < deadline && !TProxyService.TProxyIsRunning()) {
                Thread.sleep(100L);
            }
            if (!TProxyService.TProxyIsRunning()) throw new IllegalStateException("Hev tunnel did not become ready.");

            running = true;
            starting = false;
            updateNotification("Frago فعال است · TCP Fragment + UDP Direct");
            broadcastStatus("connected");
        } catch (Throwable e) {
            Log.e(TAG, "Could not start Frago", e);
            String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            stopTunnel("error: " + message);
        }
    }

    private void stopTunnel() { stopTunnel("disconnected"); }

    private synchronized void stopTunnel(String finalStatus) {
        starting = false;
        running = false;
        try { TProxyService.TProxyStopService(); } catch (Throwable e) { Log.w(TAG, "Hev stop failed", e); }
        if (socksServer != null) {
            socksServer.stop();
            socksServer = null;
        }
        if (tun != null) {
            try { tun.close(); } catch (Exception ignored) { }
            tun = null;
        }
        socksUsername = null;
        socksPassword = null;
        stopForeground(true);
        broadcastStatus(finalStatus);
        stopSelf();
    }

    @Override public void onRevoke() { stopTunnel(); super.onRevoke(); }
    @Override public void onDestroy() { stopTunnel(); super.onDestroy(); }

    private static String toHex(byte[] bytes) {
        char[] hex = "0123456789abcdef".toCharArray();
        char[] result = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int value = bytes[i] & 0xff;
            result[i * 2] = hex[value >>> 4];
            result[i * 2 + 1] = hex[value & 0x0f];
        }
        return new String(result);
    }

    private Notification buildNotification(String message) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Frago VPN", NotificationManager.IMPORTANCE_LOW));
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent content = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return builder.setSmallIcon(R.drawable.ic_vpn)
                .setContentTitle("Frago")
                .setContentText(message)
                .setContentIntent(content)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_LOW)
                .build();
    }

    private void updateNotification(String message) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(41, buildNotification(message));
    }

    private void broadcastStatus(String status) {
        Intent intent = new Intent(ACTION_STATUS).setPackage(getPackageName()).putExtra(EXTRA_STATUS, status);
        sendBroadcast(intent);
    }
}
