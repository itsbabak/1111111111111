package net.typeblog.socks.core;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Executes the supported Xray-style field routing rules in their configured order. */
public final class FragoRouting {
    private static final class Rule {
        final String outbound;
        final String network;
        final List<Pattern> domains;
        final List<Cidr> ips;

        Rule(String outbound, String network, List<Pattern> domains, List<Cidr> ips) {
            this.outbound = outbound;
            this.network = network;
            this.domains = domains;
            this.ips = ips;
        }
    }

    private static final class Cidr {
        final byte[] network;
        final int prefix;
        Cidr(String value) throws Exception {
            String[] parts = value.split("/", 2);
            InetAddress address = InetAddress.getByName(parts[0]);
            network = address.getAddress();
            prefix = parts.length == 1 ? network.length * 8 : Integer.parseInt(parts[1]);
            if (prefix < 0 || prefix > network.length * 8) throw new IllegalArgumentException("Invalid CIDR: " + value);
        }
        boolean contains(String value) {
            try {
                byte[] candidate = InetAddress.getByName(value).getAddress();
                if (candidate.length != network.length) return false;
                int full = prefix / 8;
                int bits = prefix % 8;
                for (int i = 0; i < full; i++) if (candidate[i] != network[i]) return false;
                if (bits != 0) {
                    int mask = 0xff << (8 - bits);
                    if (((candidate[full] & 0xff) & mask) != ((network[full] & 0xff) & mask)) return false;
                }
                return true;
            } catch (Exception ignored) { return false; }
        }
    }

    private final List<Rule> rules;

    private FragoRouting(List<Rule> rules) { this.rules = Collections.unmodifiableList(rules); }

    public static FragoRouting parse(JSONObject routing) throws JSONException {
        if (routing == null) throw new JSONException("بخش routing پیدا نشد.");
        if (!"AsIs".equalsIgnoreCase(routing.optString("domainStrategy", "AsIs")))
            throw new JSONException("routing.domainStrategy باید AsIs باشد.");
        JSONArray array = routing.optJSONArray("rules");
        if (array == null || array.length() == 0) throw new JSONException("routing.rules خالی است.");

        List<Rule> parsed = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            if (!"field".equalsIgnoreCase(item.optString("type", "field")))
                throw new JSONException("فقط routing rule از نوع field پشتیبانی می‌شود.");
            String outbound = item.optString("outboundTag", "");
            if (!"direct".equals(outbound) && !"fragment-out".equals(outbound))
                throw new JSONException("outboundTag پشتیبانی‌نشده در routing: " + outbound);

            String network = item.optString("network", "").toLowerCase(Locale.ROOT);
            if (!network.isEmpty() && !"tcp".equals(network) && !"udp".equals(network) && !"tcp,udp".equals(network) && !"udp,tcp".equals(network))
                throw new JSONException("network پشتیبانی‌نشده در routing: " + network);

            List<Pattern> domains = new ArrayList<>();
            JSONArray domainArray = item.optJSONArray("domain");
            if (domainArray != null) {
                for (int j = 0; j < domainArray.length(); j++) {
                    String value = domainArray.optString(j, "");
                    if (value.startsWith("regexp:")) {
                        try { domains.add(Pattern.compile(value.substring(7), Pattern.CASE_INSENSITIVE)); }
                        catch (Exception e) { throw new JSONException("عبارت regex دامنه نامعتبر است: " + value); }
                    } else if (value.startsWith("domain:")) {
                        String suffix = value.substring(7).toLowerCase(Locale.ROOT);
                        domains.add(Pattern.compile("(?:^|\\.)" + Pattern.quote(suffix) + "$", Pattern.CASE_INSENSITIVE));
                    } else if (value.startsWith("full:")) {
                        domains.add(Pattern.compile("^" + Pattern.quote(value.substring(5)) + "$", Pattern.CASE_INSENSITIVE));
                    } else {
                        String suffix = value.toLowerCase(Locale.ROOT);
                        domains.add(Pattern.compile("(?:^|\\.)" + Pattern.quote(suffix) + "$", Pattern.CASE_INSENSITIVE));
                    }
                }
            }

            List<Cidr> ips = new ArrayList<>();
            JSONArray ipArray = item.optJSONArray("ip");
            if (ipArray != null) {
                for (int j = 0; j < ipArray.length(); j++) {
                    try { ips.add(new Cidr(ipArray.getString(j))); }
                    catch (Exception e) { throw new JSONException("محدوده IP نامعتبر است: " + ipArray.optString(j)); }
                }
            }
            if (network.isEmpty() && domains.isEmpty() && ips.isEmpty())
                throw new JSONException("قانون routing فاقد شرط قابل اجرا است.");
            parsed.add(new Rule(outbound, network, domains, ips));
        }
        if (parsed.isEmpty()) throw new JSONException("هیچ قانون routing قابل اجرایی پیدا نشد.");
        return new FragoRouting(parsed);
    }

    /** First-match semantics. Domain and IP rules are evaluated before the TCP catch-all. */
    public boolean shouldFragmentTcp(String host) {
        String normalized = host == null ? "" : host.trim().toLowerCase(Locale.ROOT);
        boolean ipLiteral = isIpLiteral(normalized);
        for (Rule rule : rules) {
            if (!rule.network.isEmpty() && !rule.network.contains("tcp")) continue;
            if (!rule.domains.isEmpty()) {
                boolean match = false;
                for (Pattern pattern : rule.domains) if (pattern.matcher(normalized).matches()) { match = true; break; }
                if (!match) continue;
                return "fragment-out".equals(rule.outbound);
            }
            if (!rule.ips.isEmpty()) {
                if (!ipLiteral) continue; // domainStrategy=AsIs: do not resolve names for IP rules
                boolean match = false;
                for (Cidr cidr : rule.ips) if (cidr.contains(normalized)) { match = true; break; }
                if (!match) continue;
                return "fragment-out".equals(rule.outbound);
            }
            if (!rule.network.isEmpty()) return "fragment-out".equals(rule.outbound);
        }
        return false;
    }

    public boolean isUdpDirect() {
        for (Rule rule : rules) {
            if (!rule.network.isEmpty() && rule.network.contains("udp")) return "direct".equals(rule.outbound);
        }
        return false;
    }

    private static boolean isIpLiteral(String host) {
        return host.indexOf(':') >= 0 || host.matches("[0-9.]+");
    }
}
