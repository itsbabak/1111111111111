package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import net.typeblog.socks.core.FragoConfig;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Compact UI for importing and running the Frago-supported JSON subset. */
public final class MainActivity extends Activity {
    private static final int REQUEST_VPN = 501;
    private static final int REQUEST_JSON = 502;
    private static final String PREFS = "frago-settings";
    private static final String KEY_JSON = "json";
    private static final String KEY_ALLOWED_APPS = "allowed_apps";

    private EditText jsonEditor;
    private TextView statusView;
    private TextView appsSummary;
    private String pendingConfig;
    private boolean receiverRegistered;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String status = intent.getStringExtra(FragoVpnService.EXTRA_STATUS);
            if (status != null) setStatus(status);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        jsonEditor.setText(loadConfig());
        setStatus("آماده · JSON را بررسی و اتصال را فعال کنید");
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(FragoVpnService.ACTION_STATUS);
        registerReceiver(statusReceiver, filter);
        receiverRegistered = true;
    }

    @Override protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(statusReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(16));
        root.setBackgroundColor(0xff101820);

        TextView title = new TextView(this);
        title.setText("FRAGO");
        title.setTextSize(27);
        title.setTextColor(0xffe5edf5);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("JSON Tunnel · TLS Fragment · Direct UDP · DoH");
        subtitle.setTextSize(12);
        subtitle.setTextColor(0xff9cb0c2);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.bottomMargin = dp(14);
        root.addView(subtitle, subLp);

        statusView = new TextView(this);
        statusView.setTextColor(0xffd0e0ee);
        statusView.setTextSize(13);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackgroundColor(0xff1c2b38);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.bottomMargin = dp(12);
        root.addView(statusView, statusLp);

        jsonEditor = new EditText(this);
        jsonEditor.setTextColor(0xffe4edf5);
        jsonEditor.setHintTextColor(0xff728598);
        jsonEditor.setHint("Paste your JSON configuration here...");
        jsonEditor.setTextSize(11);
        jsonEditor.setTypeface(android.graphics.Typeface.MONOSPACE);
        jsonEditor.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        jsonEditor.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE |
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        jsonEditor.setPadding(dp(12), dp(12), dp(12), dp(12));
        jsonEditor.setBackgroundColor(0xff17232e);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(jsonEditor, new ScrollView.LayoutParams(-1, -1));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout buttons1 = new LinearLayout(this);
        buttons1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams buttonsLp = new LinearLayout.LayoutParams(-1, -2);
        buttonsLp.topMargin = dp(12);
        root.addView(buttons1, buttonsLp);
        Button importButton = makeButton("واردکردن JSON", 0xff314a5f);
        Button saveButton = makeButton("ذخیره", 0xff314a5f);
        buttons1.addView(importButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(0, dp(48), 1);
        saveLp.leftMargin = dp(8);
        buttons1.addView(saveButton, saveLp);

        Button appsButton = makeButton("انتخاب برنامه‌های VPN", 0xff314a5f);
        LinearLayout.LayoutParams appsLp = new LinearLayout.LayoutParams(-1, dp(46));
        appsLp.topMargin = dp(8);
        root.addView(appsButton, appsLp);

        appsSummary = new TextView(this);
        appsSummary.setTextColor(0xff9cb0c2);
        appsSummary.setTextSize(11);
        appsSummary.setPadding(dp(2), dp(4), dp(2), dp(4));
        root.addView(appsSummary, new LinearLayout.LayoutParams(-1, -2));
        refreshAppsSummary();

        LinearLayout buttons2 = new LinearLayout(this);
        buttons2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams connectLp = new LinearLayout.LayoutParams(-1, -2);
        connectLp.topMargin = dp(8);
        root.addView(buttons2, connectLp);
        Button connectButton = makeButton("اتصال", 0xff13795b);
        Button disconnectButton = makeButton("قطع اتصال", 0xff8e3b45);
        buttons2.addView(connectButton, new LinearLayout.LayoutParams(0, dp(50), 1));
        LinearLayout.LayoutParams disconnectLp = new LinearLayout.LayoutParams(0, dp(50), 1);
        disconnectLp.leftMargin = dp(8);
        buttons2.addView(disconnectButton, disconnectLp);

        TextView footer = new TextView(this);
        footer.setText("Frago برای ARM64 · Android 7+ · بدون Xray");
        footer.setTextColor(0xff71879a);
        footer.setTextSize(11);
        footer.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(12);
        root.addView(footer, footerLp);

        setContentView(root);
        importButton.setOnClickListener(v -> importJson());
        saveButton.setOnClickListener(v -> saveConfig(true));
        connectButton.setOnClickListener(v -> connect());
        disconnectButton.setOnClickListener(v -> disconnect());
        appsButton.setOnClickListener(v -> showAppPicker());
    }

    private static final class AppEntry {
        final String packageName;
        final String label;
        AppEntry(String packageName, String label) {
            this.packageName = packageName;
            this.label = label;
        }
    }

    private Set<String> loadAllowedApps() {
        Set<String> stored = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getStringSet(KEY_ALLOWED_APPS, Collections.<String>emptySet());
        return new HashSet<>(stored == null ? Collections.<String>emptySet() : stored);
    }

    private void saveAllowedApps(Set<String> packages) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putStringSet(KEY_ALLOWED_APPS, new HashSet<>(packages)).apply();
        refreshAppsSummary();
    }

    private void refreshAppsSummary() {
        if (appsSummary == null) return;
        int count = loadAllowedApps().size();
        appsSummary.setText(count == 0
                ? "حالت فعلی: همه برنامه‌ها از VPN استفاده می‌کنند (به‌جز خود Frago)"
                : "حالت فعلی: فقط " + count + " برنامه انتخاب‌شده از VPN استفاده می‌کنند");
    }

    private List<AppEntry> getLaunchableApps() {
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> resolved = pm.queryIntentActivities(launcher, 0);
        java.util.Map<String, AppEntry> unique = new java.util.HashMap<>();
        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName == null || packageName.equals(getPackageName())) continue;
            CharSequence label = info.loadLabel(pm);
            String title = label == null ? packageName : label.toString();
            unique.put(packageName, new AppEntry(packageName, title));
        }
        List<AppEntry> apps = new ArrayList<>(unique.values());
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override public int compare(AppEntry a, AppEntry b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        return apps;
    }

    private void showAppPicker() {
        List<AppEntry> apps = getLaunchableApps();
        if (apps.isEmpty()) {
            toast("برنامه قابل انتخابی پیدا نشد.");
            return;
        }

        Set<String> selected = loadAllowedApps();
        String[] labels = new String[apps.size()];
        boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < apps.size(); i++) {
            AppEntry app = apps.get(i);
            labels[i] = app.label;
            checked[i] = selected.contains(app.packageName);
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("برنامه‌های مجاز برای VPN")
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) ->
                        checked[which] = isChecked)
                .setPositiveButton("ذخیره", (d, which) -> {
                    Set<String> result = new HashSet<>();
                    for (int i = 0; i < apps.size(); i++) {
                        if (checked[i]) result.add(apps.get(i).packageName);
                    }
                    saveAllowedApps(result);
                    toast(result.isEmpty()
                            ? "حالت همه برنامه‌ها فعال شد"
                            : result.size() + " برنامه برای VPN انتخاب شد");
                })
                .setNegativeButton("انصراف", null)
                .setNeutralButton("پاک‌کردن انتخاب‌ها (همه برنامه‌ها)", (d, which) -> {
                    saveAllowedApps(Collections.<String>emptySet());
                    toast("حالت همه برنامه‌ها فعال شد");
                })
                .create();
        dialog.show();
    }

    private Button makeButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(0xffffffff);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return button;
    }

    private void importJson() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        try { startActivityForResult(intent, REQUEST_JSON); }
        catch (Exception e) { toast("انتخاب فایل ممکن نیست: " + e.getMessage()); }
    }

    private void connect() {
        String config = jsonEditor.getText().toString();
        try {
            FragoConfig.parse(config);
            pendingConfig = config;
            saveConfig(false);
        } catch (Exception e) {
            toast("JSON پشتیبانی نمی‌شود: " + e.getMessage());
            return;
        }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, REQUEST_VPN);
        else startTunnel();
    }

    private void startTunnel() {
        if (pendingConfig == null) pendingConfig = jsonEditor.getText().toString();
        Intent service = new Intent(this, FragoVpnService.class)
                .setAction(FragoVpnService.ACTION_START)
                .putExtra(FragoVpnService.EXTRA_CONFIG, pendingConfig)
                .putStringArrayListExtra(FragoVpnService.EXTRA_ALLOWED_APPS,
                        new ArrayList<>(loadAllowedApps()));
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
        setStatus("در حال راه‌اندازی موتور مستقل Frago...");
    }

    private void disconnect() {
        stopService(new Intent(this, FragoVpnService.class));
        setStatus("درخواست قطع اتصال ارسال شد");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQUEST_VPN) {
            startTunnel();
        } else if (requestCode == REQUEST_JSON && data != null && data.getData() != null) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                if (in == null) throw new java.io.IOException("فایل باز نشد");
                String imported = new String(readAll(in), StandardCharsets.UTF_8);
                FragoConfig.parse(imported);
                jsonEditor.setText(imported);
                saveConfig(false);
                toast("JSON وارد شد");
            } catch (Exception e) {
                toast("خطا در واردکردن JSON: " + e.getMessage());
            }
        }
    }

    private String loadConfig() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_JSON, null);
        if (saved != null && !saved.trim().isEmpty()) return saved;
        try (InputStream in = getAssets().open("default-config.json")) {
            return new String(readAll(in), StandardCharsets.UTF_8);
        } catch (Exception e) { return "{}"; }
    }

    private void saveConfig(boolean showToast) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_JSON, jsonEditor.getText().toString()).apply();
        if (showToast) toast("تنظیمات ذخیره شد");
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192]; int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private void setStatus(String value) { if (statusView != null) statusView.setText(value); }
    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
