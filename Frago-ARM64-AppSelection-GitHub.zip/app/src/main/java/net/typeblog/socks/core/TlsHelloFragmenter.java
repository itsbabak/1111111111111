package net.typeblog.socks.core;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.security.SecureRandom;

/** Implements Xray freedom.fragment packets=tlshello record splitting (TLS handshake records). */
public final class TlsHelloFragmenter {
    private final int lengthMin, lengthMax, delayMinMs, delayMaxMs;
    private final SecureRandom random = new SecureRandom();

    public TlsHelloFragmenter(FragoConfig config) {
        lengthMin = config.fragmentMin;
        lengthMax = config.fragmentMax;
        delayMinMs = config.intervalMinMs;
        delayMaxMs = config.intervalMaxMs;
    }

    /** Reads the first TLS record, discovers SNI, then optionally emits split TLS records. */
    public String forward(InputStream input, OutputStream output, String targetHost) throws Exception {
        byte[] header = readPrefix(input, 5);
        if (header.length < 5) { output.write(header); output.flush(); return null; }
        int recordLength = ((header[3] & 0xff) << 8) | (header[4] & 0xff);
        if ((header[0] & 0xff) != 22 || recordLength < 4 || recordLength > 18432) {
            output.write(header); output.flush(); copy(input, output); return null;
        }
        byte[] body = readPrefix(input, recordLength);
        if (body.length != recordLength) {
            output.write(header); output.write(body); output.flush(); copy(input, output); return null;
        }

        String sni = extractSni(body);
        boolean direct = isIranianDomain(targetHost) || isIranianDomain(sni) || isPrivateAddress(targetHost);
        boolean clientHello = body.length >= 4 && (body[0] & 0xff) == 1;
        if (!direct && clientHello) {
            int offset = 0;
            while (offset < body.length) {
                int chunk = lengthMin + random.nextInt(lengthMax - lengthMin + 1);
                int end = Math.min(body.length, offset + chunk);
                int partLength = end - offset;
                output.write(header[0]);
                output.write(header[1]);
                output.write(header[2]);
                output.write((partLength >>> 8) & 0xff);
                output.write(partLength & 0xff);
                output.write(body, offset, partLength);
                output.flush();
                offset = end;
                // Xray's tlshello fragment writer waits after each emitted record,
                // including the final record, before forwarding later stream bytes.
                sleepRandomInterval();
            }
        } else {
            output.write(header); output.write(body); output.flush();
        }
        copy(input, output);
        return sni;
    }

    private void sleepRandomInterval() throws InterruptedException {
        if (delayMaxMs <= 0) return;
        int delay = delayMinMs + random.nextInt(delayMaxMs - delayMinMs + 1);
        Thread.sleep(delay);
    }

    private static byte[] readPrefix(InputStream in, int wanted) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(wanted);
        byte[] buffer = new byte[Math.min(4096, wanted)];
        while (out.size() < wanted) {
            int n = in.read(buffer, 0, Math.min(buffer.length, wanted - out.size()));
            if (n < 0) break;
            if (n == 0) continue;
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[16 * 1024];
        int n;
        while ((n = in.read(buffer)) != -1) { out.write(buffer, 0, n); out.flush(); }
    }

    private static String extractSni(byte[] handshakeRecordBody) {
        try {
            if (handshakeRecordBody.length < 42 || (handshakeRecordBody[0] & 0xff) != 1) return null;
            int p = 4; // handshake header
            p += 2 + 32; // client version and random
            int sessionLength = handshakeRecordBody[p++] & 0xff; p += sessionLength;
            int cipherLength = u16(handshakeRecordBody, p); p += 2 + cipherLength;
            int compressionLength = handshakeRecordBody[p++] & 0xff; p += compressionLength;
            if (p + 2 > handshakeRecordBody.length) return null;
            int extensionsLength = u16(handshakeRecordBody, p); p += 2;
            int extensionsEnd = Math.min(handshakeRecordBody.length, p + extensionsLength);
            while (p + 4 <= extensionsEnd) {
                int type = u16(handshakeRecordBody, p); int size = u16(handshakeRecordBody, p + 2); p += 4;
                int end = p + size;
                if (end > extensionsEnd) return null;
                if (type == 0 && p + 5 <= end) {
                    int listLength = u16(handshakeRecordBody, p); int q = p + 2; int listEnd = Math.min(end, q + listLength);
                    while (q + 3 <= listEnd) {
                        int nameType = handshakeRecordBody[q++] & 0xff;
                        int nameLength = u16(handshakeRecordBody, q); q += 2;
                        if (q + nameLength > listEnd) return null;
                        if (nameType == 0) return new String(handshakeRecordBody, q, nameLength, StandardCharsets.US_ASCII).toLowerCase(Locale.ROOT);
                        q += nameLength;
                    }
                }
                p = end;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static int u16(byte[] b, int p) { return ((b[p] & 0xff) << 8) | (b[p + 1] & 0xff); }

    private static boolean isIranianDomain(String host) {
        return host != null && host.toLowerCase(Locale.ROOT).endsWith(".ir");
    }

    private static boolean isPrivateAddress(String host) {
        if (host == null) return false;
        try {
            if (!(host.indexOf(':') >= 0 || host.matches("[0-9.]+"))) return false;
            byte[] ip = InetAddress.getByName(host).getAddress();
            if (ip.length == 4) {
                int a = ip[0] & 255, b = ip[1] & 255;
                return a == 10 || a == 127 || (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168);
            }
            return InetAddress.getByAddress(ip).isLoopbackAddress() || InetAddress.getByAddress(ip).isLinkLocalAddress() || InetAddress.getByAddress(ip).isSiteLocalAddress();
        } catch (Exception ignored) { return false; }
    }
}
