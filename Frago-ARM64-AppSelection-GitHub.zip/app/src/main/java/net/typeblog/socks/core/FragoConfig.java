package net.typeblog.socks.core;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses the deliberately small Xray-JSON subset implemented by Frago. */
public final class FragoConfig {
    public final int socksPort;
    public final String dohUrl;
    public final int fragmentMin;
    public final int fragmentMax;
    public final int intervalMinMs;
    public final int intervalMaxMs;
    public final String[] googleAddresses;
    public final FragoRouting routing;

    private FragoConfig(int socksPort, String dohUrl, int fragmentMin, int fragmentMax,
                        int intervalMinMs, int intervalMaxMs, String[] googleAddresses, FragoRouting routing) {
        this.socksPort = socksPort;
        this.dohUrl = dohUrl;
        this.fragmentMin = fragmentMin;
        this.fragmentMax = fragmentMax;
        this.intervalMinMs = intervalMinMs;
        this.intervalMaxMs = intervalMaxMs;
        this.googleAddresses = googleAddresses;
        this.routing = routing;
    }

    public static FragoConfig parse(String source) throws JSONException {
        if (source == null || source.trim().isEmpty()) throw new JSONException("JSON خالی است.");
        JSONObject root = new JSONObject(source);
        JSONObject dns = root.optJSONObject("dns");
        if (dns == null) throw new JSONException("بخش dns پیدا نشد.");
        JSONArray servers = dns.optJSONArray("servers");
        if (servers == null || servers.length() == 0) throw new JSONException("آدرس DoH پیدا نشد.");
        String dohUrl = servers.optString(0, "");
        if (!dohUrl.startsWith("https://")) throw new JSONException("در این نسخه فقط DNS-over-HTTPS پشتیبانی می‌شود.");
        if (!"UseIPv4".equalsIgnoreCase(dns.optString("queryStrategy", "UseIPv4")))
            throw new JSONException("این موتور در حال حاضر فقط queryStrategy=UseIPv4 را پشتیبانی می‌کند.");

        JSONArray inbounds = root.optJSONArray("inbounds");
        if (inbounds == null) throw new JSONException("آرایه inbounds پیدا نشد.");
        JSONObject socks = null;
        for (int i = 0; i < inbounds.length(); i++) {
            JSONObject candidate = inbounds.optJSONObject(i);
            if (candidate != null && "socks".equalsIgnoreCase(candidate.optString("protocol"))) {
                socks = candidate;
                break;
            }
        }
        if (socks == null) throw new JSONException("SOCKS inbound لازم است.");
        int port = socks.optInt("port", -1);
        if (port < 1 || port > 65535) throw new JSONException("پورت SOCKS نامعتبر است.");
        if (!"127.0.0.1".equals(socks.optString("listen", "127.0.0.1")))
            throw new JSONException("برای امنیت، SOCKS باید فقط روی 127.0.0.1 گوش کند.");
        JSONObject socksSettings = socks.optJSONObject("settings");
        if (socksSettings == null || !socksSettings.optBoolean("udp", false))
            throw new JSONException("SOCKS UDP باید فعال باشد.");

        JSONArray outbounds = root.optJSONArray("outbounds");
        if (outbounds == null) throw new JSONException("آرایه outbounds پیدا نشد.");
        JSONObject fragment = null;
        boolean direct = false;
        for (int i = 0; i < outbounds.length(); i++) {
            JSONObject item = outbounds.optJSONObject(i);
            if (item == null) continue;
            if ("fragment-out".equals(item.optString("tag"))) fragment = item;
            if ("direct".equals(item.optString("tag")) && "freedom".equals(item.optString("protocol"))) direct = true;
        }
        if (fragment == null || !"freedom".equals(fragment.optString("protocol")))
            throw new JSONException("outbound با tag=fragment-out و protocol=freedom لازم است.");
        if (!direct) throw new JSONException("outbound مستقیم با tag=direct لازم است.");
        JSONObject settings = fragment.optJSONObject("settings");
        JSONObject frag = settings == null ? null : settings.optJSONObject("fragment");
        if (frag == null || !"tlshello".equalsIgnoreCase(frag.optString("packets")))
            throw new JSONException("فقط Fragment از نوع tlshello پشتیبانی می‌شود.");
        int[] length = parseRange(frag.optString("length", ""), "fragment.length");
        int[] interval = parseRange(frag.optString("interval", ""), "fragment.interval");
        if (length[0] < 1 || length[1] > 16384 || interval[0] < 0 || interval[1] > 5000)
            throw new JSONException("محدوده length یا interval نامعتبر است.");

        JSONObject sniffing = socks.optJSONObject("sniffing");
        boolean tlsSniffing = false;
        if (sniffing != null && sniffing.optBoolean("enabled", false)) {
            JSONArray overrides = sniffing.optJSONArray("destOverride");
            if (overrides != null) for (int i = 0; i < overrides.length(); i++) {
                if ("tls".equalsIgnoreCase(overrides.optString(i))) tlsSniffing = true;
            }
        }
        if (!tlsSniffing) throw new JSONException("برای تشخیص SNI باید sniffing با destOverride=tls فعال باشد.");

        FragoRouting routing = FragoRouting.parse(root.optJSONObject("routing"));
        if (!routing.isUdpDirect())
            throw new JSONException("قانون network=udp با outboundTag=direct در routing لازم است.");

        String[] google = null;
        JSONObject hosts = dns.optJSONObject("hosts");
        if (hosts != null) {
            Iterator<String> keys = hosts.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (key.toLowerCase().contains("google")) {
                    JSONArray addresses = hosts.optJSONArray(key);
                    if (addresses != null && addresses.length() > 0) {
                        google = new String[addresses.length()];
                        for (int i = 0; i < addresses.length(); i++) google[i] = addresses.getString(i);
                    }
                }
            }
        }
        if (google == null || google.length != 2 ||
                !"65.109.184.128".equals(google[0]) || !"91.107.241.144".equals(google[1]))
            throw new JSONException("DNS hosts برای google باید شامل دو IP مشخص‌شده باشد.");
        return new FragoConfig(port, dohUrl, length[0], length[1], interval[0], interval[1], google, routing);
    }

    private static int[] parseRange(String value, String name) throws JSONException {
        Matcher m = Pattern.compile("^\\s*(\\d+)\\s*-\\s*(\\d+)\\s*$").matcher(value);
        if (!m.matches()) throw new JSONException(name + " باید به‌شکل min-max باشد.");
        int a, b;
        try { a = Integer.parseInt(m.group(1)); b = Integer.parseInt(m.group(2)); }
        catch (NumberFormatException e) { throw new JSONException(name + " نامعتبر است."); }
        if (a > b) throw new JSONException(name + " حداقل و حداکثر جابه‌جا هستند.");
        return new int[] {a, b};
    }

    public String toHevYaml(String logPath, String socksUsername, String socksPassword) {
        return "tunnel:\n" +
                "  mtu: 1500\n" +
                "  ipv4: 26.26.26.1\n" +
                "  ipv6: 'fd26:26:26::1'\n" +
                "  icmp: 'off'\n" +
                "socks5:\n" +
                "  address: 127.0.0.1\n" +
                "  port: " + socksPort + "\n" +
                "  udp: 'udp'\n" +
                "  username: '" + socksUsername.replace("'", "") + "'\n" +
                "  password: '" + socksPassword.replace("'", "") + "'\n" +
                "mapdns:\n" +
                "  address: 26.26.26.2\n" +
                "  port: 53\n" +
                "  network: 198.18.0.0\n" +
                "  netmask: 255.254.0.0\n" +
                "  cache-size: 4096\n" +
                "misc:\n" +
                "  task-stack-size: 65536\n" +
                "  tcp-buffer-size: 65536\n" +
                "  udp-recv-buffer-size: 131072\n" +
                "  max-session-count: 512\n" +
                "  log-file: '" + logPath.replace("'", "") + "'\n" +
                "  log-level: 'error'\n";
    }
}
