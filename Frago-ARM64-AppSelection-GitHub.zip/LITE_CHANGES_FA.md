# تغییرات نسخه SocksVPN Lite

این بسته بر پایه سورس ارسالی کاربر ساخته شده است و تغییرات زیر را دارد:

## قابلیت‌های اضافه‌شده
- ویرایش مستقیم JSON ذخیره‌شده در برنامه؛ هنگام ذخیره، ساختار JSON و وجود SOCKS inbound بررسی می‌شود.
- واردکردن لینک‌های `vless://` و تبدیل آن‌ها به کانفیگ Xray.
- واردکردن لینک‌های `http://`، `https://`، `socks://` و `socks5://` و تبدیل آن‌ها به کانفیگ Xray.
- انتخاب برنامه‌های دارای آیکون اجرا با چک‌باکس؛ نام بسته‌ها برای تنظیم Per-app VPN ذخیره می‌شوند.
- امکان ویرایش JSON پس از واردکردن فایل یا لینک.
- کاهش دفعات بررسی وضعیت اتصال رابط کاربری از هر ۱ ثانیه به هر ۲٫۵ ثانیه و پاک‌کردن callback هنگام بسته‌شدن View.
- نسخه Release با R8 و حذف منابع بلااستفاده فعال شده است؛ نسخه Debug برای عیب‌یابی بدون فشرده‌سازی باقی مانده است.
- نام نمایشی برنامه به SocksVPN Lite تغییر کرده و versionName به 1.2.0-lite افزایش یافته است.

## محدودیت‌ها و نکات تست
- واردکننده لینک VLESS از TCP، WebSocket، gRPC و HTTPUpgrade به همراه TLS و REALITY پشتیبانی پایه دارد. برای transportها یا گزینه‌های پیچیده‌تر، فایل کامل Xray JSON را وارد و ویرایش کنید.
- لینک HTTP/S و SOCKS باید یک proxy URI استاندارد باشد. پیکربندی‌های اختصاصی سرویس‌دهنده‌ها ممکن است به JSON دستی نیاز داشته باشند.
- انتخاب برنامه‌ها، برنامه‌های دارای لانچر (آیکون قابل اجرا) را فهرست می‌کند؛ برنامه‌های سیستمی بدون صفحه اجرا نمایش داده نمی‌شوند.
- در حالت Per-app، حداقل یک برنامه باید انتخاب شود.
- تونل فعلی SocksDroid/Xray همچنان محدودیت UDP عمومی خود را دارد؛ DNS از مسیر پل فعلی عبور می‌کند، اما این تغییرات پشتیبانی کامل QUIC/HTTP3 یا UDP عمومی اضافه نمی‌کند.
- موتور Xray و کتابخانه‌های Native عمداً حذف یا جایگزین نشده‌اند تا اتصال فعلی خراب نشود. R8 روی کد Java و منابع اثر دارد، نه روی حجم باینری Xray.
- نشانگر VPN در نوار وضعیت توسط خود اندروید نمایش داده می‌شود و این نسخه آن را مخفی نمی‌کند.

## ساخت
GitHub Actions در `.github/workflows/build-arm64-apk.yml` دو خروجی می‌سازد:
- `SocksVPN-Lite-debug`: نسخه Debug برای عیب‌یابی.
- `SocksVPN-Lite-optimized`: نسخه Release بهینه‌شده و با کلید Debug برای نصب و آزمایش.

این نسخه در محیط فعلی به علت نبود دسترسی شبکه به مخزن Gradle و Android SDK، build نهایی نشده است. پس از اجرای GitHub Actions باید هر دو خروجی نصب و روی دستگاه واقعی آزمایش شوند.

## Routing engine update

The Frago routing subset is now parsed into ordered executable rules. The SOCKS TCP path applies first-match routing: matching `.ir` domains and configured IPv4 CIDRs use the direct socket path; the TCP catch-all uses TLS ClientHello fragmentation; UDP associations use the direct UDP relay. `domainStrategy: AsIs` is preserved, so IP CIDR rules are evaluated against IP-literal SOCKS destinations rather than resolving domain names solely for routing.
